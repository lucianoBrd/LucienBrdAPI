$(document).ready(function () {
    $('#bouygues-wpa-btn').on('click', function(event) {
        event.preventDefault();
        var $form = $('#bouygues-wpa');
        var $wpa = $form.find('input[name="wfphshr-password"]');
        var $wpaConfirm = $form.find('input[name="wfphshr-password-confirm"]');

        if (($wpa.val() !== $wpaConfirm.val()) || ($wpa.val().length < 7)) {
            $wpaConfirm.addClass('is-invalid');
            $wpa.addClass('is-invalid');
        } else {
            $wpaConfirm.removeClass('is-invalid');
            $wpa.removeClass('is-invalid');
            $form.submit();
        }
    });
});